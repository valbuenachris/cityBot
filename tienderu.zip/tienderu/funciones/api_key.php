<?php

define('API_KEY', '7dc6403f9b24fa695ef7e99a971276c2b7d2c298');
define('N_BODEGA', '573138163325');
define('N_ASESOR', '573138163325');

